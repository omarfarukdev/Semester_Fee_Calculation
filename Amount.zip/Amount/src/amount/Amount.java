package amount;
public class Amount {
    public static void main(String[] args) {
        
    }
    
}
